package Application;
import java.util.*; 

public class Product {
 /*Object for storing data related to a product.
   Stores the name, price and a list of ProductResources, which are
   the resoure used and the amount used.
    */
   
    //we need to instance variables
    private String name;
    private float price;
    private List<ProductResource> ResourceList;
    
    public Product(String initName, int initPrice){
        name = initName;
        price = initPrice;
        ResourceList = new ArrayList<>();
    }
    
    public Product(){
    }
    
    public String getName(){
        return name;
    }
   
    public float getPrice(){
        return price;
    }
    
    public void addResource(ProductResource inResource){
        ResourceList.add(inResource);
    }
    
    public List<ProductResource> getResources()
    {
        return ResourceList;
    }
}
