/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Application;

public class ProductResource {
    /*
    Object that contains a resource type and amount of that resource is used.
    */
    public ProductResource(Resource initResource, int initAmount){
        resource = initResource;
        amount = initAmount;
    }
    
    public String getName()
    {
        return resource.getName();
    }
    
    public int getAmount()
    {
        return amount;
    }
        private Resource resource;
        private int amount;
}
