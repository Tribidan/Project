/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Application;

public class Resource{
    /* Object for storing a type of resource.
       Resource has a name, cost per each unit and amount of units in storage.
    */
    
    
    public Resource(String initName, int initPricePerUnit, int initStorageAmount){
        
        name = initName;
        pricePerUnit = initPricePerUnit;
        storageAmount = initStorageAmount;
    }
        private String name;
        private float pricePerUnit;
        private int storageAmount;
        
        public String getName()
        {
            return name;
        }
}
